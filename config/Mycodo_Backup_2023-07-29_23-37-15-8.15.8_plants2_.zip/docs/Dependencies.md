Page\: `[Gear Icon] -> Dependencies`

The dependency page allows viewing of dependency information and the ability to initiate their installation. This is not something you will need to normally do, as dependencies are installed on an as-needed basis. If an Input, Output, Function, or other device you're adding has unmet dependencies, you will be prompted to install them when you attempt to install that device.
